// This page created by Majdi Awad from scratch using JS

document.getElementById('applicantForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    const file = document.getElementById('cv').files[0];

    const reader = new FileReader();
    reader.onload = function() {
        const typedArray = new Uint8Array(this.result);

        pdfjsLib.getDocument({data: typedArray}).promise.then(pdf => {
            let textContent = '';

            const pages = [];
            for (let i = 1; i <= pdf.numPages; i++) {
                pages.push(pdf.getPage(i).then(page => {
                    return page.getTextContent().then(text => {
                        return text.items.map(item => item.str).join(' ');
                    });
                }));
            }

            Promise.all(pages).then(contents => {
                textContent = contents.join(' ');

                formData.append('cv_text', textContent);
                fetch('submit.php', {
                    method: 'POST',
                    body: formData
                }).then(response => response.text())
                  .then(result => {
                    alert(result);
                }).catch(error => {
                    console.error('Error:', error);
                });
            });
        });
    };
    reader.readAsArrayBuffer(file);
});
// This page created by Majdi Awad from scratch using JS
