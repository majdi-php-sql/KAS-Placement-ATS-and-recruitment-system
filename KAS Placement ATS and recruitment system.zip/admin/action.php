<?php
/////////////////////////// this code created by Majdi M. S. Awad ////////////////////////////////////////

session_start();

// Include the database connection file
require 'config/db_connect.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    // Hash the input password using MD5
    $hashed_input_password = md5($input_password);

    // Prepare and bind
    $stmt = $conn->prepare("SELECT id, username, password, email, mobile, position FROM users WHERE username = ?");
    $stmt->bind_param("s", $input_username);

    // Execute the statement
    $stmt->execute();

    // Store the result
    $stmt->store_result();

    // Bind the result variables
    $stmt->bind_result($id, $username, $hashed_password, $email, $mobile, $position);

    // Fetch the result
    if ($stmt->fetch()) {
        // Verify the password
        if ($hashed_input_password === $hashed_password) {
            // Store user information in the session
            $_SESSION['id'] = $id;
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            $_SESSION['mobile'] = $mobile;
            $_SESSION['position'] = $position;

            // Redirect to a welcome page or dashboard
            header("Location: dashboard/index.php");
            exit();
        } else {
            // Invalid password
            $_SESSION['error'] = "Invalid username or password.";
            header("Location: index.php");
            exit();
        }
    } else {
        // Invalid username
        $_SESSION['error'] = "Invalid username or password.";
        header("Location: index.php");
        exit();
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
/////////////////////////// this code created by Majdi M. S. Awad ////////////////////////////////////////

?>
