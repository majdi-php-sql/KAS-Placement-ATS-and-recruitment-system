<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Recruitment | Sales Recruiters | Marketing Headhunters</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            position: relative;
            background-image: url('bg.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.3);
            box-shadow: 0 0 15px 15px rgba(255, 255, 255, 0.3);
            z-index: 1;
        }

        .container {
            position: relative;
            z-index: 2;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 2em;
            border-radius: 1em;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .logo {
            max-width: 150px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center">
                    <img src="logo.svg" alt="Logo" class="img-fluid logo">
                </div>

                <!-- Display error message if it exists -->
                <?php
                if (isset($_SESSION['error'])) {
                    echo '<div class="alert alert-danger" role="alert">' . $_SESSION['error'] . '</div>';
                    unset($_SESSION['error']); // Clear the error message
                }
                ?>

                <form id="applicantForm" class="form-container" method="post" action="action.php">
                    <div class="form-group">
                        <label for="name">Username:</label>
                        <input type="text" id="name" name="username" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="age">Password:</label>
                        <input type="password" id="age" name="password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
<!--
This page created by Majdi Awad from scratch using HTML
-->
</html>
