<?php
// This code created by Majdi Awad for KAS Placement

require 'session.php';
require '../../config/db_connect.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form inputs
    $employer = $conn->real_escape_string($_POST['employer']);
    $position = $conn->real_escape_string($_POST['position']);
    $min_age = $conn->real_escape_string($_POST['min_age']);
    $max_age = $conn->real_escape_string($_POST['max_age']);
    $experience = $conn->real_escape_string($_POST['experience']);
    $key1 = $conn->real_escape_string($_POST['key1']);
    $key2 = $conn->real_escape_string($_POST['key2']);
    $key3 = $conn->real_escape_string($_POST['key3']);
    $key4 = $conn->real_escape_string($_POST['key4']);
    $key5 = $conn->real_escape_string($_POST['key5']);
    $job_description = $conn->real_escape_string($_POST['job_description']);
    $gender = $conn->real_escape_string($_POST['gender']);

    // Insert the data into the selected table
    $sql = "INSERT INTO employers (employer, position, min_age, max_age, experience, key1, key2, key3, key4, key5, job_description, gender) 
            VALUES ('$employer', '$position', '$min_age', '$max_age', '$experience', '$key1', '$key2', '$key3', '$key4', '$key5', '$job_description', '$gender')";

    if ($conn->query($sql) === TRUE) {
        header ('Location: ../index.php');
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request.";
}
// This code created by Majdi Awad for KAS Placement

?>
