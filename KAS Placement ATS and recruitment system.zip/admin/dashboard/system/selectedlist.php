<?php
// This code created by Majdi Awad for KAS Placement

// Fetch applicants data
$applicantsQuery = "SELECT * FROM selected"; // Ensure the table name is correct
$applicantsResult = $conn->query($applicantsQuery);

if ($conn->error) {
    die("Query failed: " . $conn->error);
}
// This code created by Majdi Awad for KAS Placement
