<?php
// This code created by Majdi Awad for KAS Placement

require 'session.php';
require '../../config/db_connect.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form inputs
    $id = $conn->real_escape_string($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $age = $conn->real_escape_string($_POST['age']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $cv = $conn->real_escape_string($_POST['cv']);
    $cv_file = $conn->real_escape_string($_POST['cv_file']);
    $employer = $conn->real_escape_string($_POST['employer']);
    $position = $conn->real_escape_string($_POST['position']);
    $interview_date = $conn->real_escape_string($_POST['interview_date']);
    $interview_time = $conn->real_escape_string($_POST['interview_time']);
    $comments = $conn->real_escape_string($_POST['comments']);

    // Insert the data into the shortlisted table
    $sql = "INSERT INTO shortlisted (id, name, age, gender, cv, cv_file, employer, position, interview_date, interview_time, comments) 
            VALUES ('$id', '$name', '$age', '$gender', '$cv', '$cv_file', '$employer', '$position', '$interview_date', '$interview_time', '$comments')";

    if ($conn->query($sql) === TRUE) {
        // If the insertion is successful, delete the applicant from the applicants table
        $sql = "DELETE FROM applicants WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            header("Location: ../applicants.php");
            exit();
        } else {
            echo "Error deleting applicant: " . $conn->error;
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request.";
}
// This code created by Majdi Awad for KAS Placement

?>
