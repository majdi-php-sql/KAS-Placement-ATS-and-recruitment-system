<?php
// This code created by Majdi Awad for KAS Placement

session_start();

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    // User is not logged in, redirect to the login page
    header("Location: index.php");
    exit();
}

// Sanitize session data for safe output
$username = htmlspecialchars($_SESSION['username']);
$email = htmlspecialchars($_SESSION['email']);
$mobile = htmlspecialchars($_SESSION['mobile']);
$position = htmlspecialchars($_SESSION['position']);
// This code created by Majdi Awad for KAS Placement

?>