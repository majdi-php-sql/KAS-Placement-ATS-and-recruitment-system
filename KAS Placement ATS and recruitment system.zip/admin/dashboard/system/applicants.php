<?php
// This code created by Majdi Awad for KAS Placement

require '../config/db_connect.php';

$sql = "SELECT * FROM applicants";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
        
$row = $result->fetch_assoc();

}
// This code created by Majdi Awad for KAS Placement
