<?php
// This code created by Majdi Awad for KAS Placement

require 'session.php';
require '../../config/db_connect.php';

// Step 1: Get the ID from the URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Step 2: Select all data from "shortlisted" table based on the ID
    $selectQuery = "SELECT * FROM shortlisted WHERE id = ?";
    if ($stmt = $conn->prepare($selectQuery)) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            
            // Step 3: Insert data into "selected" table
            $name = $row['name'];
            $age = $row['age'];
            $gender = $row['gender'];
            $employer = $row['employer'];
            $position = $row['position'];
            $dateTime = date('Y-m-d H:i:s');
            
            $insertQuery = "INSERT INTO selected (id, name, age, gender, employer, position, date_time) VALUES (?, ?, ?, ?, ?, ?, ?)";
            if ($insertStmt = $conn->prepare($insertQuery)) {
                $insertStmt->bind_param("issssss", $id, $name, $age, $gender, $employer, $position, $dateTime);
                if ($insertStmt->execute()) {
                    
                    // Step 4: Remove the record from the "shortlisted" table based on the ID
                    $deleteQuery = "DELETE FROM shortlisted WHERE id = ?";
                    if ($deleteStmt = $conn->prepare($deleteQuery)) {
                        $deleteStmt->bind_param("i", $id);
                        if ($deleteStmt->execute()) {
                            
                            // Step 5: Redirect the user to ../shortlisted.php
                            header("Location: ../shortlisted.php");
                            exit;
                        } else {
                            echo "Error deleting record: " . $conn->error;
                        }
                    } else {
                        echo "Error preparing delete statement: " . $conn->error;
                    }
                } else {
                    echo "Error inserting record: " . $conn->error;
                }
            } else {
                echo "Error preparing insert statement: " . $conn->error;
            }
        } else {
            echo "No record found with the given ID.";
        }
        $stmt->close();
    } else {
        echo "Error preparing select statement: " . $conn->error;
    }
} else {
    echo "Invalid request: ID not set.";
}

$conn->close();
// This code created by Majdi Awad for KAS Placement

?>
