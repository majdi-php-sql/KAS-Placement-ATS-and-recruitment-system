<?php
// Created by Majdi Awad for KAS Placement

require 'system/session.php';
require '../config/db_connect.php';

$output = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Step 1: Get the data entered from the form
    $employer_entered = $_POST['employer'];
    $position_entered = $_POST['position'];

    // Step 2: Select all from 'employers' table where employer and position match
    $employers_query = "SELECT * FROM employers WHERE employer='$employer_entered' AND position='$position_entered'";
    $employers_result = $conn->query($employers_query);

    if (!$employers_result) {
        die("Error executing employers query: " . $conn->error);
    }

    $employer_data = $employers_result->fetch_assoc();

    if (!$employer_data) {
        $output .= "No employer found with the specified criteria.";
    } else {
        // Step 3: Select all from 'applicants' table
        $applicants_query = "SELECT * FROM applicants";
        $applicants_result = $conn->query($applicants_query);

        if (!$applicants_result) {
            die("Error executing applicants query: " . $conn->error);
        }

        $best_candidate = null;
        $highest_score = 0;

        // Step 4: Score each candidate
        while ($candidate = $applicants_result->fetch_assoc()) {
            $score = 0;

            // 4.a: Gender score
            $score += ($candidate['gender'] == $employer_data['gender']) ? 100 : 20;

            // 4.c: Age score
            $age = $candidate['age'];
            if ($age >= $employer_data['min_age'] && $age <= $employer_data['max_age']) {
                $score += 100;
            } else {
                $score += 20;
            }

            // 4.e to 4.n: Keyword scores (ignore case)
            $cv = strtolower($candidate['cv']);
            $keywords = ['key1', 'key2', 'key3', 'key4', 'key5'];
            foreach ($keywords as $keyword) {
                $score += (stripos($cv, strtolower($employer_data[$keyword])) !== false) ? 100 : 0;
            }

            // Step 5: NLP comparison between 'cv' and 'job_description'
            similar_text(strtolower($candidate['cv']), strtolower($employer_data['job_description']), $nlp_score);
            $score += $nlp_score;

            // Determine if this candidate is the best so far
            if ($score > $highest_score) {
                $highest_score = $score;
                $best_candidate = $candidate;
            }
        }

        if ($best_candidate) {
            // Step 7: Print all data for the best candidate
            $output .= "<h3>Best Candidate:</h3>";
            $output .= "<p>Name: " . htmlspecialchars($best_candidate['name']) . "</p>";
            $output .= "<p>Age: " . htmlspecialchars($best_candidate['age']) . "</p>";
            $output .= "<p>Gender: " . htmlspecialchars($best_candidate['gender']) . "</p>";
            $output .= "<p>CV: <a href='" . htmlspecialchars($best_candidate['cv_file']) . "'>Download CV</a></p>";

            // Step 8: Generate an explanation paragraph
            $output .= "<h3>Explanation:</h3>";
            $output .= "<p>The selected candidate is the best fit for the position of " . htmlspecialchars($position_entered) . " at " . htmlspecialchars($employer_entered) . " because they scored the highest in our evaluation. ";
            $output .= "Their gender matched the requirement, and their age fell within the specified range. ";
            $output .= "Their CV contained the necessary keywords and closely matched the job description. ";
            $output .= "Overall, their qualifications and experience make them the ideal candidate for this role.</p>";
        } else {
            $output .= "No candidate found for the selected employer and position.";
        }
    }
} else {
    $output .= "Invalid request method.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sales Recruitment | Sales Recruiters | Marketing Headhunters</title>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        .download-link, .download-link:visited, .download-link:hover, .download-link:active {
            color: darkred;
            text-decoration: none; /* Optional: To remove underline */
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-label {
            font-weight: bold;
        }
        .form-container {
            background: #fff;
            padding: 20px;
            border-radius: 5px;
        }
        .form-row {
            display: flex;
            justify-content: space-between;
        }
        .form-col {
            flex: 0 0 48%;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="tm-header">
                <a href="index.php" class="tm-site-name">KAS Placement</a>
                <div class="mobile-menu-icon">
                  <i class="fa fa-bars"></i>
                </div>
                <nav class="tm-nav">
                    <ul>
                        <li><a href="index.php" class="active">Home</a></li>
                        <li><a href="applicants.php">Applicants</a></li>
                        <li><a href="vacancies.php">Vacancies</a></li>
                        <li><a href="../logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <div class="tm-banner tm-bn-1">
        <div class="container">
            <div class="row">
                <div class="tm-banner-text">
                    <div class="tm-banner-text-inner">
                        <h1 class="tm-banner-title"><?php echo "Welcome " . htmlspecialchars($_SESSION['username']); ?></h1>
                        <p class="tm-banner-description">To your dashboard</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="form-container">
                <form action="" method="POST">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label class="form-label" for="employer">Employer:</label>
                                <select id="employer" name="employer" class="form-control">
                                    <!-- Populate this dropdown from the 'employers' table -->
                                    <?php
                                    $employers_list_query = "SELECT DISTINCT employer FROM employers";
                                    $employers_list_result = $conn->query($employers_list_query);
                                    if ($employers_list_result) {
                                        while ($row = $employers_list_result->fetch_assoc()) {
                                            echo "<option value='" . $row['employer'] . "'>" . htmlspecialchars($row['employer']) . "</option>";
                                        }
                                    } else {
                                        echo "<option value=''>No employers found</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label class="form-label" for="position">Position:</label>
                                <select id="position" name="position" class="form-control">
                                    <!-- Populate this dropdown from the 'employers' table -->
                                    <?php
                                    $positions_list_query = "SELECT DISTINCT position FROM employers";
                                    $positions_list_result = $conn->query($positions_list_query);
                                    if ($positions_list_result) {
                                        while ($row = $positions_list_result->fetch_assoc()) {
                                            echo "<option value='" . $row['position'] . "'>" . htmlspecialchars($row['position']) . "</option>";
                                                                                }
                                    } else {
                                        echo "<option value=''>No positions found</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Find Best Candidate</button>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="form-container">
                <!-- Display the output generated by PHP -->
                <?php echo $output; ?>
            </div>
        </div>
        <div class="row">
            <div class="tm-block-2-container">
                <div class="tm-block-2 tm-block-order-2">
                    <div class="tm-footer-block tm-blue-box tm-footer-text-container">
                        <h3 class="tm-footer-text-title">Sales Recruitment | Sales Recruiters | Marketing Headhunters</h3>
                    </div>
                </div>
                <div class="tm-block-2 tm-block-order-1">
                    <p class="tm-footer-block tm-copyright-text">
                        Copyright &copy; 2024 KAS Placement 
                        | Design: <a rel="nofollow" href="https://www.kasplacement.com/" target="_parent">KAS Placement</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script> <!-- jQuery -->
    <script type="text/javascript" src="js/templatemo-script.js"></script> <!-- Templatemo Script -->
</body>
</html>

										
