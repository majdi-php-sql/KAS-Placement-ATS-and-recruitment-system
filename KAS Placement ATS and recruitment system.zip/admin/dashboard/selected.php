<?php
//Created by Majdi Awad for KAS Placement

require 'system/session.php';
require '../config/db_connect.php';
require 'system/selectedlist.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!--
Created by Majdi Awad for KAS Placement

    -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sales Recruitment | Sales Recruiters | Marketing Headhunters</title>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        .download-link, .download-link:visited, .download-link:hover, .download-link:active {
            color: darkred;
            text-decoration: none; /* Optional: To remove underline */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="tm-header">
                <a href="index.php" class="tm-site-name">KAS Placement</a>
                <div class="mobile-menu-icon">
                  <i class="fa fa-bars"></i>
                </div>
                <nav class="tm-nav">
                    <ul>
                        <li><a href="index.php" class="active">Home</a></li>
                        <li><a href="applicants.php">Applicants</a></li>
                        <li><a href="vacancies.php">Vacancies</a></li>
                        <li><a href="../logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>          
        </div>      
    </div>
    <div class="tm-banner tm-bn-3">
        <div class="container">
            <div class="row">
                <div class="tm-banner-text">
                    <div class="tm-banner-text-inner">
                        <h1 class="tm-banner-title"><?php echo "Welcome " . htmlspecialchars($_SESSION['username']); ?></h1>
                        <p class="tm-banner-description">To your dashboard</p>
                    </div>  
                </div>          
            </div>          
        </div>          
    </div>  
    <div class="container">
        <div class="row">
            <div style="background:#fff; padding:15px;" class="tm-blocks-container">
            <table class="table table-striped table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Age</th>
						<th>Gender</th>
                        <th>Employer</th>
                        <th>Position</th>
						<th>Acceptness Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($applicantsResult && $applicantsResult->num_rows > 0) {
                        // Output data of each row
                        while ($row = $applicantsResult->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['age']) . "</td>";
							echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['employer']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['position']) . "</td>";
							echo "<td>" . htmlspecialchars($row['date_time']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No applicants found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            </div>
            </div>          
        </div>      
        <div class="row">
            <div class="tm-block-2-container">          
                
                <div class="tm-block-2 tm-block-order-2">
                    <div class="tm-footer-block tm-blue-box tm-footer-text-container">
                        <h3 class="tm-footer-text-title">Sales Recruitment | Sales Recruiters | Marketing Headhunters</h3>
                    </div>
                </div>  
                <div class="tm-block-2 tm-block-order-1">
                    <p class="tm-footer-block tm-copyright-text">
                        Copyright &copy; 2024 KAS Placement 
                        | Design: <a rel="nofollow" href="https://www.kasplacement.com/" target="_parent">KAS Placement</a>
                    </p>
                </div>          
            </div>              
        </div>                
    </div>
    
    <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
    <script type="text/javascript" src="js/templatemo-script.js"></script>      <!-- Templatemo Script -->

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
