<?php
// Created by Majdi Awad for KAS Placement

// Include database connection and initialization file
require 'system/session.php';
require '../config/db_connect.php';

// Retrieve data from the database
$sqlApplicants = "SELECT COUNT(*) as count FROM applicants";
$sqlShortlisted = "SELECT COUNT(*) as count FROM shortlisted";
$sqlSelected = "SELECT COUNT(*) as count FROM selected";
$sqlPositions = "SELECT position, COUNT(*) as count FROM employers GROUP BY position";
$sqlAgeDistribution = "SELECT age, COUNT(*) as count FROM applicants GROUP BY age";
$sqlGenderDistribution = "SELECT gender, COUNT(*) as count FROM applicants GROUP BY gender";
$sqlSelectedGenderDistribution = "SELECT gender, COUNT(*) as count FROM selected GROUP BY gender";

$resultApplicants = $conn->query($sqlApplicants);
$resultShortlisted = $conn->query($sqlShortlisted);
$resultSelected = $conn->query($sqlSelected);
$resultPositions = $conn->query($sqlPositions);
$resultAgeDistribution = $conn->query($sqlAgeDistribution);
$resultGenderDistribution = $conn->query($sqlGenderDistribution);
$resultSelectedGenderDistribution = $conn->query($sqlSelectedGenderDistribution);

// Fetch data from query results
$applicantsCount = $resultApplicants->fetch_assoc()['count'];
$shortlistedCount = $resultShortlisted->fetch_assoc()['count'];
$selectedCount = $resultSelected->fetch_assoc()['count'];

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--
Created by Majdi Awad for KAS Placement

-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sales Recruitment | Sales Recruiters | Marketing Headhunters</title>
	<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        .download-link, .download-link:visited, .download-link:hover, .download-link:active {
            color: darkred;
            text-decoration: none; /* Optional: To remove underline */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="tm-header">
                <a href="index.php" class="tm-site-name">KAS Placement</a>
                <div class="mobile-menu-icon">
                  <i class="fa fa-bars"></i>
                </div>
                <nav class="tm-nav">
                    <ul>
                        <li><a href="index.php" class="active">Home</a></li>
                        <li><a href="applicants.php">Applicants</a></li>
                        <li><a href="vacancies.php">Vacancies</a></li>
                        <li><a href="../logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>          
        </div>      
    </div>
    <div class="tm-banner tm-bn-2">
        <div class="container">
            <div class="row">
                <div class="tm-banner-text">
                    <div class="tm-banner-text-inner">
                        <h1 class="tm-banner-title"><?php echo "Welcome " . htmlspecialchars($_SESSION['username']); ?></h1>
                        <p class="tm-banner-description">To your dashboard</p>
                    </div>  
                </div>          
            </div>          
        </div>          
    </div>  
    <div class="container">
        <div class="row">
            <div style="height: 100%; background:#fff; padding:15px;" class="tm-blocks-container">
    <div>
        <h2>Number of Records</h2>
        <canvas id="recordsChart"></canvas>
    </div>

    <div>
        <h2>Positions Distribution</h2>
        <canvas id="positionsChart"></canvas>
    </div>

    <div>
        <h2>Age Distribution</h2>
        <canvas id="ageChart"></canvas>
    </div>

    <div>
        <h2>Gender Distribution</h2>
        <canvas id="genderChart"></canvas>
    </div>

    <div>
        <h2>Selected Gender Distribution</h2>
        <canvas id="selectedGenderChart"></canvas>
    </div>

    <script>
        // Data for charts
        var applicantsCount = <?php echo $applicantsCount; ?>;
        var shortlistedCount = <?php echo $shortlistedCount; ?>;
        var selectedCount = <?php echo $selectedCount; ?>;
        var positionsData = <?php echo json_encode($resultPositions->fetch_all(MYSQLI_ASSOC)); ?>;
        var ageData = <?php echo json_encode($resultAgeDistribution->fetch_all(MYSQLI_ASSOC)); ?>;
        var genderData = <?php echo json_encode($resultGenderDistribution->fetch_all(MYSQLI_ASSOC)); ?>;
        var selectedGenderData = <?php echo json_encode($resultSelectedGenderDistribution->fetch_all(MYSQLI_ASSOC)); ?>;

        // Function to create charts
        function createChart(chartId, chartType, labels, data, label) {
            var ctx = document.getElementById(chartId).getContext('2d');
            var chart = new Chart(ctx, {
                type: chartType,
                data: {
                    labels: labels,
                    datasets: [{
                        label: label,
                        data: data,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true
                            }
                        }]
                    }
                }
            });
        }

        // Create charts
        createChart('recordsChart', 'bar', ['Applicants', 'Shortlisted', 'Selected'], [applicantsCount, shortlistedCount, selectedCount], 'Number of Records');
        createChart('positionsChart', 'pie', positionsData.map(item => item.position), positionsData.map(item => item.count), 'Positions Distribution');
        createChart('ageChart', 'bar', ageData.map(item => item.age), ageData.map(item => item.count), 'Age Distribution');
        createChart('genderChart', 'pie', genderData.map(item => item.gender), genderData.map(item => item.count), 'Gender Distribution');
        createChart('selectedGenderChart', 'bar', selectedGenderData.map(item => item.gender), selectedGenderData.map(item => item.count), 'Selected Gender Distribution');
    </script>            </div>
            </div>          
        </div>      
        <div class="row">
            <div class="tm-block-2-container">          
                
                <div class="tm-block-2 tm-block-order-2">
                    <div class="tm-footer-block tm-blue-box tm-footer-text-container">
                        <h3 class="tm-footer-text-title">Sales Recruitment | Sales Recruiters | Marketing Headhunters</h3>
                    </div>
                </div>  
                <div class="tm-block-2 tm-block-order-1">
                    <p class="tm-footer-block tm-copyright-text">
                        Copyright &copy; 2024 KAS Placement 
                        | Design: <a rel="nofollow" href="https://www.kasplacement.com/" target="_parent">KAS Placement</a>
                    </p>
                </div>          
            </div>              
        </div>                
    </div>
    
    <script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
    <script type="text/javascript" src="js/templatemo-script.js"></script>      <!-- Templatemo Script -->

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
