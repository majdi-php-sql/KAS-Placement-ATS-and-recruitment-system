<?php
//Created by Majdi Awad for KAS Placement

require 'system/session.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
<!--
Created by Majdi Awad for KAS Placement

-->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sales Recruitment | Sales Recruiters | Marketing Headhunters</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/templatemo-style.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
	<div class="container">
		<div class="row">
			<div class="tm-header">
				<a href="index.php" class="tm-site-name">KAS Placement</a>
				<div class="mobile-menu-icon">
	              <i class="fa fa-bars"></i>
	            </div>
				<nav class="tm-nav">
					<ul>
						<li><a href="index.php" class="active">Home</a></li>
						<li><a href="applicants.php">Applicants</a></li>
						<li><a href="vacancies.php">Vacancies</a></li>
						<li><a href="../logout.php">Logout</a></li>
					</ul>
				</nav>
			</div>			
		</div>		
	</div>
	<div class="tm-banner tm-bn-1">
		<div class="container">
			<div class="row">
				<div class="tm-banner-text">
					<div class="tm-banner-text-inner">
						<h1 class="tm-banner-title"><?php echo "Welcome " . $username; ?></h1>
						<p class="tm-banner-description">To your dashboard</p>
					</div>	
				</div>			
			</div>			
		</div>			
	</div>	
	<div class="container">
		<div class="row">
			<div class="tm-blocks-container">
				<div class="tm-home-left">
					<div class="tm-2-columns">						
						<div class="tm-home-block-small tm-img-text tm-position-relative tm-white-box">
							
							<a href="applicants.php"><h2 class="tm-h2">New Applicants</h2></a>
							<p class="text-justify tm-gray-text">Explore all new applicants and find an amazing talents...</p>	
						</div>
						<div class="tm-home-block-small tm-position-relative">
							<i class="fa fa-4x fa-caret-right tm-triangle-right"></i>
							<img src="img/home-1.jpg" alt="image" class="tm-home-img-1">	
						</div>										
					</div>					
					<div class="tm-home-block-big tm-position-relative">
						<div class="tm-red-box tm-img-overlay tm-img-overlay-1">
							<p><a href="selected.php" style="color:#fff;">Explore selected Applicants</a></p>	
						</div>						
						<img src="img/home-3.jpg" alt="image" class="img-responsive">
					</div>
					<div class="tm-2-columns">						
						<div class="tm-home-block-small tm-img-text tm-position-relative tm-white-box">
							
							<a href="vacancies.php"><h2 class="tm-h2">Add Vacancies</h2></a>
							<p>Employer and job description</p>
						</div>				
						<div class="tm-home-block-small tm-position-relative">
							<img src="img/home-5.jpg" alt="image" class="tm-home-img-1">		
						</div>						
					</div>
				</div>			
				<div class="tm-home-right">
					<div class="tm-home-block-big tm-position-relative tm-home-img-big-2-container">
						<div class="tm-blue-box tm-img-overlay tm-img-overlay-2">
							<p><a href="shortlisted.php" style="color:#fff;">Explore Shortlisted Applicants</a></p>	
						</div>						
						<img src="img/home-2.jpg" alt="image" class="img-responsive">
					</div>
					<div class="tm-home-block-big tm-2-columns-tall">
						<div class="col tm-intro-container tm-position-relative tm-white-box">
							
							<a href="ai.php"><h2 class="tm-h2">Recruit With AI</h2></a>
							<p class="tm-gray-text tm-intro-description">This feature will help you because it will use an artificial neural network to compare resumes with job descriptions and identify the best 5 candidates for the job. You can rely on this feature to select candidates by using  a carefully designed mathematical model.</p>
							<a href="ai.php" class="tm-button tm-blue-button margin-top-30">Find the one</a>				
						</div>
						<div class="col tm-2-rows tm-2-rows-2">
							<div class="tm-home-block-small tm-home-img-1-container">
								<img src="img/home-4.jpg" alt="image" class="tm-home-img-1">	
							</div>							
							<div class="tm-home-block-small padding-30 tm-dark-box tm-dark-box-img-text">
								<h2 class="tm-h2 tm-dark-gray-text">Generate Custom Reports </h2>
						        <a href="reports.php" class="tm-button tm-blue-button margin-top-15">Generate Now</a>
						    </div>	
						</div>						
					</div>					
				</div>
			</div>			
		</div>		
		<div class="row">
			<div class="tm-block-2-container">			
				
				<div class="tm-block-2 tm-block-order-2">
					<div class="tm-footer-block tm-blue-box tm-footer-text-container">
						<h3 class="tm-footer-text-title">Sales Recruitment | Sales Recruiters | Marketing Headhunters</h3>
					</div>
				</div>	
				<div class="tm-block-2 tm-block-order-1">
					<p class="tm-footer-block tm-copyright-text">
                    	Copyright &copy; 2024 KAS Placement 
                    	| Design: <a rel="nofollow" href="https://www.kasplacement.com/" target="_parent">KAS Placement</a>
                    </p>
				</div>			
			</div>				
		</div>			  			  	
	</div>
	
	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
	<script type="text/javascript" src="js/templatemo-script.js"></script>      <!-- Templatemo Script -->

</body>
</html>
