<?php
/////////////////////////// this code created by Majdi M. S. Awad ////////////////////////////////////////

// Database connection parameters
$servername = "localhost";
$user = "root";
$password = "Majdi@00800";
$dbname = "ats";

// Create connection
$conn = new mysqli($servername, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}