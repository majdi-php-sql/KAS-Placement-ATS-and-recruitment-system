<?php
// This page created by Majdi Awad from scratch using PHP

$servername = "localhost";
$username = "root";
$password = "Majdi@00800";
$dbname = "ats";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$cv_text = $_POST['cv_text'];

$uploadDir = 'uploads/';
$uploadFile = $uploadDir . basename($_FILES['cv']['name']);
$pdfPath = '';

if (move_uploaded_file($_FILES['cv']['tmp_name'], $uploadFile)) {
    $pdfPath = $uploadFile;
} else {
    echo "Error uploading file.";
    exit;
}

$stmt = $conn->prepare("INSERT INTO applicants (name, age, gender, cv, cv_file) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sisss", $name, $age, $gender, $cv_text, $pdfPath);

if ($stmt->execute()) {
    echo "New record created successfully";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
// This page created by Majdi Awad from scratch using PHP

?>
